<?php include'includefile/header.php' ?>
<?php include'includefile/adminnav.php' ?>
<br><br>
<h1>
<a href="addfood.php"><i class="fa fa-plus" style="font-size:60px;color:black; position: relative;
  left: 1300px;"></i></a></h1>
<br><br><br>
<?php include'includefile/food.php' ?>
<?php include'includefile/footer.php' ?>
