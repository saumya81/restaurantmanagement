
<?php include'includefile/header.php' ?>
    <body>
    <!-- Navigation -->
<?php include'includefile/navindex.php' ?>
     

<!-- Page Content -->

<div><img src="img/about-banner.jpg" width="1550" height="500"></div>
    

<!--      about me-->
<section class="my-5">
        <div class="py-5">
    <h2 class="text-center"> ABOUT THE AUTHOR</h2>
    </div>
    <div class="container-fluid">
    <div class="row">
        <div class="col-lg-4 col-md-4 col-12"> 
            <img src="img/saumya.jpg" class="img-fluid aboutimg" style="border:1px solid black;border-radius:20px;  box-shadow: 5px 10px 18px #888888;">
        </div>
        <div class="col-lg-8 col-md-8 col-12"> 
            <h1 >Hey Guys</h1>
            <h5 class="py-3 mr-5 ml-3">I'm Saumya Shrivastava.I have made this website for my assignment in internshala .If you want to know me more you can visit my portfolio website.
            I am a computer science engineering student having good knowledge of different domains in computer science . I am a quick learner and always ready to learn different skills . I have a worked with different startups and always open to new projects of my field in order to enhance my skillset.</h5>
            
        </div>
    
    </div>
    
    </div>    
        </section> 
          <?php include'includefile/ourservice.php' ?>
        <?php include'includefile/ourmotto.php' ?>
        
   <br><br>     
        
    
<!-- seller registration       -->
        
        <?php include'includefile/footerindex.php' ?>
