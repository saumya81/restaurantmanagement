 <section class="my-5 ">
      <div class="container-fluid">
  <h1 class="text-center">Our Services</h1>
  
  <div class="row ml-5">
    <div class="col-sm-4 my-5 " ><img src="img/variety-logo-3.png" width="300" height="150" >  </div>
    <div class="col-sm-4" ><img src="img/fff.png" ></div>
    <div class="col-sm-4" style="width=200;height=200;"><img src="img/hd.jpg"></div>
    
  </div>
</div>
        
        
        
        </section>