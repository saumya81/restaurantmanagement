
<div class="list-unstyled list-inline text-center py-2" style="background-color:black;color:white;width:100%;height:100px">
            <h1>Register Your Restaurant in FoodShala
        <a href="admin/adminregistration.php" class="btn btn-outline-white btn-danger btn-rounded">Register </a></h1>
      
        </div>
<footer class="page-footer font-small text-white-50 bg-dark pt-4">

  <!-- Footer Elements -->
  <div class="container ">

    <!-- Call to action -->
    <ul class="list-unstyled list-inline text-center py-2">
      <li class="list-inline-item">
        <h5 class="mb-1">Login as Restaurant Owner</h5>
      </li>
      <li class="list-inline-item">
        <a href="admin/index.php" class="btn btn-outline-white btn-danger btn-rounded">Log-in</a>
      </li>
    </ul>
    <!-- Call to action -->

  </div>
  <!-- Footer Elements -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="https://mdbootstrap.com/"> SaumyaRestro</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
       
    
    </body>


</html>