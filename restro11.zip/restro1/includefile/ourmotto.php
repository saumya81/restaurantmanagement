<div class="container-fluid pr-4 pl-4">
  <h1 class="text-center">Our Motto</h1><br><br>
  
  <div class="row">
    <div class="col-sm-4" ><h3>Resilience</h3><p> We push ourselves beyond our abilities when faced with tough times. When we foresee uncertainty, we address it only with flexibility.</p> </div>
    <div class="col-sm-4" ><h3>Acceptance</h3><p>Feedback is never taken personally, we break it into positive pieces and strive to work on each and every element even more effectively.</p> </div>
    <div class="col-sm-4" ><h3>Ownership</h3><p>People here don’t work ‘for’ FoodShala, they work ‘with’ FoodShala. We treat every problem as our own, take accountability and drive the change.</p> </div>
    
  </div>
</div>
        